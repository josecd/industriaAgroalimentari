﻿using System;
using System.Collections.Generic;
using System.Text;

namespace industria
{
    class Class1 : Products
    {
    }
}
